package project;

import java.awt.*;
import javax.swing.*;
import java.util.regex.Pattern;
import java.awt.Container;
import java.awt.event.*;

import java.sql.*;

public class homePage extends JFrame {
    ImageIcon img;
    JLabel background;
    JLabel mess;
    JPanel panel;
    JLabel login;
    Container container;
    JLabel username;
    JTextField userfield;
    JLabel Password;
    JTextField passfield;
    JButton submit;
    JButton clear;
    JButton Signup;
    String url = "jdbc:mysql://localhost:3306/login";
    String user = "root";
    String password = "ranjan5044";
    Connection con;
    ResultSet rs, rs1;
    Statement st, st1;

    homePage() {
        // try {
        // Connection con = (Connection) DriverManager
        // .getConnection("jdbc:mysql://localhost:4306/?user=root&password=");
        // con.close();
        // } catch (Exception e) {
        // System.out.println(e);
        // }

        container = getContentPane();
        container.setLayout(null);

        ImageIcon i = new ImageIcon(getClass().getResource("menu.jpg"));
        JLabel header = new JLabel(i);
        header.setBounds(0, 0, 1200, 55);
        add(header);

        JPanel panel1 = new JPanel();
        panel1.setBackground(new Color(0, 100, 250, 100));
        panel1.setLocation(0, 55);
        panel1.setSize(1200, 40);
        panel1.setLayout(null);
        panel1.setBorder(BorderFactory.createEtchedBorder(2, Color.BLACK, Color.BLACK));
        add(panel1);

        JLabel f11 = new JLabel("Home");
        f11.setForeground(Color.WHITE);
        f11.setFont(new Font("", Font.BOLD, 15));
        f11.setBounds(20, 2, 100, 30);
        panel1.add(f11);

        JLabel f12 = new JLabel("Products & Services");
        f12.setForeground(Color.WHITE);
        f12.setFont(new Font("", Font.BOLD, 15));
        f12.setBounds(120, 2, 200, 30);
        panel1.add(f12);

        JLabel f13 = new JLabel("How Do I");
        f13.setFont(new Font("", Font.BOLD, 15));
        f13.setForeground(Color.WHITE);
        f13.setBounds(330, 2, 100, 30);
        panel1.add(f13);

        JLabel f14 = new JLabel("Manage Debit Card E-Mandate");
        f14.setFont(new Font("", Font.BOLD, 15));
        f14.setForeground(Color.WHITE);
        f14.setBounds(430, 2, 250, 30);
        panel1.add(f14);

        JLabel f15 = new JLabel("Contact Us");
        f15.setFont(new Font("", Font.BOLD, 15));
        f15.setForeground(Color.WHITE);
        f15.setBounds(700, 2, 150, 30);
        panel1.add(f15);

        JPanel panel2 = new JPanel();
        panel2.setBackground(new Color(0, 100, 170, 100));
        panel2.setLocation(0, 95);
        panel2.setSize(1200, 40);
        panel2.setLayout(null);
        panel2.setBorder(BorderFactory.createEtchedBorder());
        add(panel2);

        JLabel f2 = new JLabel("Welcome to Personal Internet Banking");
        f2.setFont(new Font("", Font.BOLD, 15));
        f2.setBounds(10, 2, 300, 30);
        panel2.add(f2);

        JLabel f3 = new JLabel(
                "Dear Customer, Mandatory login and profile password change introduced for added security.");
        f3.setForeground(Color.RED);
        f3.setFont(new Font("", Font.BOLD, 15));
        f3.setBounds(400, 2, 800, 30);
        panel2.add(f3);

        // JLabel f4 = new JLabel("Welcome to Personal Internet Banking");
        // f4.setFont(new Font("", Font.BOLD, 15));
        // f4.setBounds(1000, 2, 200, 30);
        // panel1.add(f4);

        // img = new ImageIcon(getClass().getResource("img3.jpg"));
        background = new JLabel();
        background.setBackground(new Color(0, 100, 182, 100));
        background.setBounds(0, 90, 1200, 700);
        add(background);

        panel = new JPanel();
        panel.setBackground(new Color(0, 100, 182, 100));
        panel.setLocation(50, 150);
        panel.setSize(400, 400);
        panel.setLayout(null);
        panel.setBorder(BorderFactory.createEtchedBorder(50, Color.BLACK, Color.BLACK));
        background.add(panel);

        login = new JLabel("Login System");
        login.setFont(new Font("", Font.BOLD, 20));
        login.setForeground(Color.BLACK);
        login.setBounds(80, 0, 600, 50);
        panel.add(login);

        username = new JLabel("Email :");
        username.setForeground(Color.BLACK);
        username.setFont(new Font("", Font.BOLD, 20));
        username.setBounds(100, 50, 200, 30);
        panel.add(username);

        userfield = new JTextField();
        userfield.setBounds(100, 80, 200, 30);
        panel.add(userfield);

        Password = new JLabel("Password :");
        Password.setForeground(Color.BLACK);
        Password.setFont(new Font("", Font.BOLD, 20));
        Password.setBounds(100, 110, 200, 30);
        panel.add(Password);

        JPasswordField passfield = new JPasswordField();
        passfield.setBounds(100, 140, 200, 30);
        panel.add(passfield);

        submit = new JButton();
        submit.setText("Login");
        submit.setForeground(Color.BLACK);
        submit.setBounds(100, 200, 200, 30);
        panel.add(submit);
        submit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String email = userfield.getText();
                String pass = passfield.getText();

                String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\." +
                        "[a-zA-Z0-9_+&*-]+)*@" +
                        "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                        "A-Z]{2,7}$";

                Pattern pat = Pattern.compile(emailRegex);
                if (pat.matcher(email).matches()) {
                } else {
                    JOptionPane.showMessageDialog(login, "Invalid Email Id ! ");
                    System.exit(0);
                }
                try {
                    Connection con = (Connection) DriverManager
                            .getConnection("jdbc:mysql://localhost:3306/login", "root", "ranjan5044");
                    String query = "Select pass from bank where email=?";
                    PreparedStatement x = (PreparedStatement) con.prepareStatement(query);
                    x.setString(1, email);
                    ResultSet rs = x.executeQuery();
                    while (rs.next()) {
                        String name = rs.getString("pass");
                        if (pass.compareTo(name) == 0) {
                            new Bankprocess();
                        } else {
                            JOptionPane.showMessageDialog(panel, "Username and password do not matched !");
                        }
                    }
                    con.close();
                } catch (Exception exception) {
                    System.out.println(exception);
                }
            }
        });

        clear = new JButton();
        clear.setForeground(Color.BLACK);
        clear.setText("Clear");
        clear.setBounds(100, 250, 200, 30);
        panel.add(clear);
        clear.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                userfield.setText("");
                passfield.setText("");
            }
        });

        Signup = new JButton();
        Signup.setForeground(Color.BLACK);
        Signup.setText("Create New Account");
        Signup.setBounds(100, 300, 200, 30);
        panel.add(Signup);
        Signup.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new Register();
            }
        });

    }

    public static void main(String[] args) {

        homePage frame = new homePage();
        frame.setTitle("Login page");
        frame.setBackground(Color.CYAN);
        frame.setVisible(true);
        frame.setLocation(100, 100);
        frame.setSize(1200, 700);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(true);
        frame.setBackground(Color.LIGHT_GRAY);

    }
}
