package project;

import java.awt.*;
import javax.swing.*;
import java.util.regex.Pattern;
import java.awt.Container;
import java.awt.event.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoField;

import java.sql.*;

public class Bank2Process extends JFrame {
    String name;

    Bank2Process(int flag, String name, long acc, double balance) {
        this.name = name;
        Container container = getContentPane();
        container.setLayout(null);

        ImageIcon img = new ImageIcon(getClass().getResource("img6.JPG"));
        JLabel background = new JLabel(img);
        background.setBounds(0, 0, 1200, 700);
        add(background);

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBounds(350, 150, 500, 400);
        panel.setBackground(new Color(0, 0, 0, 180));
        panel.setBorder(BorderFactory.createEtchedBorder(50, Color.BLACK, Color.BLACK));
        background.add(panel);

        String t = "";
        if (flag == 1) {
            t = "Withdraw details";
        } else if (flag == 2) {
            t = "Deposit details";
        }
        JLabel title = new JLabel(t);
        title.setForeground(Color.RED);
        title.setFont(new Font("", Font.BOLD, 25));
        title.setBounds(125, 0, 200, 30);
        panel.add(title);

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter df = DateTimeFormatter.ofPattern("dd-mm-yyyy  hh:mm:ss");
        String date = now.format(df);

        JLabel dt = new JLabel(date);
        dt.setForeground(Color.RED);
        dt.setFont(new Font("", Font.BOLD, 15));
        dt.setBounds(250, 50, 250, 20);
        panel.add(dt);

        JLabel printAccl = new JLabel("Account No :");
        printAccl.setForeground(Color.RED);
        printAccl.setFont(new Font("", Font.BOLD, 15));
        printAccl.setBounds(50, 80, 100, 20);
        panel.add(printAccl);
        String accountno = "" + acc;

        JLabel printAcc = new JLabel(accountno);
        printAcc.setForeground(Color.RED);
        printAcc.setFont(new Font("", Font.BOLD, 15));
        printAcc.setBounds(150, 80, 150, 20);
        panel.add(printAcc);

        JLabel printnamel = new JLabel("Name :");
        printnamel.setForeground(Color.RED);
        printnamel.setFont(new Font("", Font.BOLD, 15));
        printnamel.setBounds(50, 120, 100, 20);
        panel.add(printnamel);

        JLabel printname = new JLabel(name);
        printname.setForeground(Color.RED);
        printname.setFont(new Font("", Font.BOLD, 15));
        printname.setBounds(150, 120, 100, 20);
        panel.add(printname);

        JLabel printBalancel = new JLabel("Balance :");
        printBalancel.setForeground(Color.RED);
        printBalancel.setFont(new Font("", Font.BOLD, 15));
        printBalancel.setBounds(50, 160, 100, 20);
        panel.add(printBalancel);

        String bal = "" + balance;
        JLabel printBalance = new JLabel(bal);
        printBalance.setForeground(Color.RED);
        printBalance.setFont(new Font("", Font.BOLD, 15));
        printBalance.setBounds(150, 160, 100, 20);
        panel.add(printBalance);

        setLocation(100, 100);
        setSize(1200, 700);
        setVisible(true);

    }

    public static void main(String[] args) {

    }
}
