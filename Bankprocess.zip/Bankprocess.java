package project;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EtchedBorder;

import java.awt.event.*;
import java.sql.*;

public class Bankprocess extends JFrame {
    Container cont;
    ImageIcon img;
    JLabel back;
    JPanel panel;
    JPanel panel2;
    JLabel title;
    JLabel id;
    JTextField idfield;
    JLabel pin;
    JPasswordField pinfiled;
    JButton submit;
    JLabel printAccl;
    JLabel printnamel;
    JLabel printBalancel;
    JTextField printAc;
    JTextField printname;
    JTextField printBalance;
    JLabel amount;
    JTextField amountf;
    JButton withraw;
    JButton Deposit;
    double intial = 0;
    double famount = 0;
    String name = "";

    Bankprocess() {

        cont = getContentPane();
        cont.setLayout(null);

        img = new ImageIcon(getClass().getResource("img6.jpg"));
        back = new JLabel(img);
        back.setBounds(0, 0, 1200, 700);
        add(back);

        panel = new JPanel();
        panel.setBackground(new Color(0, 0, 0, 190));
        panel.setLocation(450, 100);
        panel.setSize(300, 300);
        panel.setLayout(null);
        panel.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED, Color.BLACK, Color.BLACK));
        back.add(panel);

        id = new JLabel("Account No : ");
        id.setForeground(Color.RED);
        id.setFont(new Font("", Font.BOLD, 15));
        id.setBounds(50, 50, 150, 20);
        panel.add(id);

        idfield = new JTextField();
        idfield.setBounds(50, 70, 150, 30);
        panel.add(idfield);

        pin = new JLabel("Enter pin : ");
        pin.setForeground(Color.RED);
        pin.setFont(new Font("", Font.BOLD, 15));
        pin.setBounds(50, 105, 100, 20);
        panel.add(pin);

        pinfiled = new JPasswordField();
        pinfiled.setBounds(50, 125, 150, 30);
        panel.add(pinfiled);

        panel2 = new JPanel();
        panel2.setBackground(new Color(0, 0, 0, 180));
        panel2.setLocation(400, 100);
        panel2.setSize(400, 400);
        panel2.setLayout(null);
        panel2.setBorder(BorderFactory.createEtchedBorder(Color.BLACK, Color.BLACK));
        back.add(panel2);
        panel2.setVisible(false);

        printAccl = new JLabel("Account No :");
        printAccl.setForeground(Color.RED);
        printAccl.setFont(new Font("", Font.BOLD, 15));
        printAccl.setBounds(70, 50, 100, 20);
        panel2.add(printAccl);

        printnamel = new JLabel("Name :");
        printnamel.setForeground(Color.RED);
        printnamel.setFont(new Font("", Font.BOLD, 15));
        printnamel.setBounds(230, 50, 100, 20);
        panel2.add(printnamel);

        printBalancel = new JLabel("Balance :");
        printBalancel.setForeground(Color.RED);
        printBalancel.setFont(new Font("", Font.BOLD, 15));
        printBalancel.setBounds(170, 100, 100, 20);
        panel2.add(printBalancel);

        amount = new JLabel("Enter Amount :");
        amount.setForeground(Color.RED);
        amount.setFont(new Font("", Font.BOLD, 15));
        amount.setBounds(140, 200, 200, 20);
        panel2.add(amount);

        submit = new JButton("Submit");
        submit.setBounds(50, 170, 100, 30);
        panel.add(submit);

        submit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                long s1 = Long.parseLong(idfield.getText());
                int s = Integer.parseInt(pinfiled.getText());
                if (idfield.getText().equals("") || pinfiled.getText().equals("")) {
                    JOptionPane.showMessageDialog(panel, "Enter Email or password!");
                }
                try {
                    Connection con = (Connection) DriverManager
                            .getConnection("jdbc:mysql://localhost:3306/login", "root", "ranjan5044");
                    String query = "Select pin from bank where Adhar=?";
                    PreparedStatement x = (PreparedStatement) con.prepareStatement(query);
                    x.setLong(1, s1);
                    ResultSet rs = x.executeQuery();
                    while (rs.next()) {
                        int num = rs.getInt("pin");
                        if (s != num) {
                            JOptionPane.showMessageDialog(panel, "Wrong password!");
                        }
                        if (s == num) {
                            double i = 0;
                            String fname = "";
                            String lname = "";
                            try {
                                Connection con1 = (Connection) DriverManager
                                        .getConnection("jdbc:mysql://localhost:3306/login", "root",
                                                "ranjan5044");
                                String query1 = "Select Amount,fname,lname from bank where Adhar =?";
                                PreparedStatement st = (PreparedStatement) con1.prepareStatement(query1);
                                st.setLong(1, s1);
                                ResultSet result = st.executeQuery();
                                result.next();
                                i = result.getDouble("Amount");
                                fname = result.getString("fname");
                                lname = result.getString("lname");
                                System.out.println(i);
                                con1.close();
                            } catch (Exception exception) {
                                System.out.println(exception);
                            }
                            panel.setVisible(false);
                            panel2.setVisible(true);

                            printAc = new JTextField(" " + s1 + "");
                            printAc.setBounds(50, 70, 145, 30);
                            panel2.add(printAc);

                            printname = new JTextField(" " + fname + " " + lname);
                            printname.setBounds(200, 70, 150, 30);
                            panel2.add(printname);

                            printBalance = new JTextField(" " + i + "");
                            printBalance.setBounds(130, 120, 150, 30);
                            panel2.add(printBalance);

                            amountf = new JTextField();
                            amountf.setBounds(130, 220, 150, 30);
                            panel2.add(amountf);

                            withraw = new JButton("Withdraw");
                            withraw.setBounds(100, 270, 100, 30);
                            panel2.add(withraw);
                            withraw.addActionListener(new ActionListener() {
                                public void actionPerformed(ActionEvent e) {
                                    int ch = JOptionPane.showConfirmDialog(null, "Are you sure ?");
                                    if (ch == 0) {
                                        double amount = Double.parseDouble(amountf.getText());
                                        double i = 0;
                                        double f = 0;
                                        String fname = "";
                                        String lname = "";
                                        try {
                                            Connection con1 = (Connection) DriverManager
                                                    .getConnection("jdbc:mysql://localhost:3306/login", "root",
                                                            "ranjan5044");
                                            String query1 = "Select Amount,fname,lname from bank where Adhar =?";
                                            PreparedStatement st = (PreparedStatement) con1.prepareStatement(query1);
                                            st.setLong(1, s1);
                                            ResultSet result = st.executeQuery();
                                            result.next();
                                            i = result.getDouble("Amount");
                                            fname = result.getString("fname");
                                            lname = result.getString("lname");

                                            con1.close();
                                        } catch (Exception exception) {
                                            System.out.println(exception);
                                        }
                                        try {
                                            Connection con2 = (Connection) DriverManager
                                                    .getConnection("jdbc:mysql://localhost:3306/login", "root",
                                                            "ranjan5044");
                                            String query2 = "update bank set Amount= ? where Adhar=?";
                                            PreparedStatement st2 = (PreparedStatement) con2.prepareStatement(query2);
                                            f = i - amount;
                                            printBalance.setText(" " + f + "");
                                            System.out.println(f);
                                            st2.setDouble(1, f);
                                            st2.setLong(2, s1);
                                            int x = st2.executeUpdate();
                                            if (x == 1) {
                                                String nname1 = "" + fname + " " + lname;
                                                new Bank2Process(1, nname1, s1, f);
                                            }
                                            con2.close();

                                        } catch (Exception exception) {
                                            System.out.println(exception);
                                        }
                                    }
                                }
                            });

                            Deposit = new JButton("Deposit");
                            Deposit.setBounds(205, 270, 100, 30);
                            panel2.add(Deposit);
                            Deposit.addActionListener(new ActionListener() {
                                public void actionPerformed(ActionEvent e) {
                                    int ch = JOptionPane.showConfirmDialog(null, "Are you sure ?");
                                    if (ch == 0) {
                                        double amount = Double.parseDouble(amountf.getText());
                                        double i = 0;
                                        double f = 0;
                                        String fname = "";
                                        String lname = "";
                                        try {
                                            Connection con1 = (Connection) DriverManager
                                                    .getConnection("jdbc:mysql://localhost:3306/login", "root",
                                                            "ranjan5044");
                                            String query1 = "Select Amount,fname,lname from bank where Adhar =?";
                                            PreparedStatement st = (PreparedStatement) con1.prepareStatement(query1);
                                            st.setLong(1, s1);
                                            ResultSet result = st.executeQuery();
                                            result.next();
                                            i = result.getDouble("Amount");
                                            fname = result.getString("fname");
                                            lname = result.getString("lname");
                                            System.out.println(i);
                                            con1.close();
                                        } catch (Exception exception) {
                                            System.out.println(exception);
                                        }
                                        try {
                                            Connection con2 = (Connection) DriverManager
                                                    .getConnection("jdbc:mysql://localhost:3306/login", "root",
                                                            "ranjan5044");
                                            String query2 = "update bank set Amount= ? where Adhar=?";
                                            PreparedStatement st2 = (PreparedStatement) con2.prepareStatement(query2);
                                            f = i + amount;
                                            printBalance.setText(" " + f + "");
                                            System.out.println(f);
                                            st2.setDouble(1, f);
                                            st2.setLong(2, s1);
                                            int x = st2.executeUpdate();
                                            if (x == 1) {
                                                String nname1 = "" + fname + " " + lname;
                                                new Bank2Process(2, nname1, s1, f);
                                            }
                                            con2.close();
                                            new homePage();

                                        } catch (Exception exception) {
                                            System.out.println(exception);
                                        }
                                    }
                                }
                            });
                        } else {
                            JOptionPane.showMessageDialog(panel, "Wrong Account Number or Pin number");
                        }
                    }
                    con.close();
                } catch (Exception exception) {
                    System.out.println(exception);
                }

            }
        });
        setTitle("BankProcess");
        setVisible(true);
        setLocation(100, 100);
        setSize(1200, 700);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);
        setBackground(Color.LIGHT_GRAY);
    }

    public static void main(String[] args) {
        new Bankprocess();
    }
}
